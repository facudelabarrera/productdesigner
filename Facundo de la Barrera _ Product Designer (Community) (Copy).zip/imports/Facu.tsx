import svgPaths from "./svg-3aq2xgmvsu";
import imgD8E6Eb6B345Ada088E2448947C483Ab42 from "figma:asset/caae806975928a75c46c1bc680021f992f457e15.png";
import imgD8E6Eb6B345Ada088E2448947C483Ab43 from "figma:asset/c7d606c54e3dae29bb244748d6905ec049756c18.png";
import imgD8E6Eb6B345Ada088E2448947C483Ab44 from "figma:asset/1f82fe59e0070aa7fe9b9bd980ca9d7a7b457ad2.png";
import imgD8E6Eb6B345Ada088E2448947C483Ab45 from "figma:asset/2ad366052b8413ad8588cb503f693fe5682fc2fe.png";
import imgD8E6Eb6B345Ada088E2448947C483Ab46 from "figma:asset/00b2769ad960ac1a1a52d41a886f4e89812fcc8f.png";
import imgD8E6Eb6B345Ada088E2448947C483Ab47 from "figma:asset/27a964f1166648e57c09876bbdc96b0a29d3e018.png";

function Palette() {
  return (
    <div className="relative size-full" data-name="palette">
      <div className="absolute inset-[8.333%]" data-name="Icon">
        <div className="absolute inset-[-5%]">
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 22 22"
          >
            <g id="Icon">
              <path
                d={svgPaths.pe01380}
                stroke="var(--stroke-0, white)"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
              />
              <path
                d={svgPaths.p29896c00}
                stroke="var(--stroke-0, white)"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
              />
              <path
                d={svgPaths.p12634d80}
                stroke="var(--stroke-0, white)"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
              />
              <path
                d={svgPaths.p81bc040}
                stroke="var(--stroke-0, white)"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
              />
            </g>
          </svg>
        </div>
      </div>
    </div>
  );
}

function Logomark() {
  return (
    <div
      className="[grid-area:1_/_1] h-[29.684px] ml-0 mt-0 relative w-[24.737px]"
      data-name="Logomark"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 25 30"
      >
        <g id="Logomark" opacity="0.84">
          <path
            clipRule="evenodd"
            d={svgPaths.p272b2500}
            fill="var(--fill-0, white)"
            fillRule="evenodd"
            id="Vector"
            opacity="0.5"
          />
          <path
            clipRule="evenodd"
            d={svgPaths.p1a6dcb80}
            fill="var(--fill-0, white)"
            fillRule="evenodd"
            id="Vector_2"
            opacity="0.7"
          />
          <path
            clipRule="evenodd"
            d={svgPaths.p5344000}
            fill="var(--fill-0, white)"
            fillRule="evenodd"
            id="Vector_3"
          />
        </g>
      </svg>
    </div>
  );
}

function Logotext() {
  return (
    <div
      className="[grid-area:1_/_1] h-[29.684px] ml-[30.921px] mt-0 relative w-[63.079px]"
      data-name="Logotext"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 64 30"
      >
        <g id="Logotext" opacity="0.84">
          <g id="Vector">
            <path d={svgPaths.p3d58b100} fill="var(--fill-0, white)" />
            <path
              clipRule="evenodd"
              d={svgPaths.p18325570}
              fill="var(--fill-0, white)"
              fillRule="evenodd"
            />
            <path
              clipRule="evenodd"
              d={svgPaths.p2c470900}
              fill="var(--fill-0, white)"
              fillRule="evenodd"
            />
            <path d={svgPaths.p4c4ba80} fill="var(--fill-0, white)" />
            <path
              clipRule="evenodd"
              d={svgPaths.p21aa5300}
              fill="var(--fill-0, white)"
              fillRule="evenodd"
            />
            <path d={svgPaths.p2e87ff00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p14573b00} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Group1() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Logomark />
      <Logotext />
    </div>
  );
}

function Behance() {
  return (
    <div className="relative shrink-0 size-5" data-name="behance">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="behance">
          <g id="vector">
            <path
              clipRule="evenodd"
              d={svgPaths.p41be400}
              fill="var(--fill-0, #CCCCCC)"
              fillRule="evenodd"
            />
            <path
              clipRule="evenodd"
              d={svgPaths.p1d84bf00}
              fill="var(--fill-0, #CCCCCC)"
              fillRule="evenodd"
            />
            <path d={svgPaths.p162acff0} fill="var(--fill-0, #CCCCCC)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Instagram() {
  return (
    <div className="relative shrink-0 size-5" data-name="instagram">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="instagram">
          <g id="vector">
            <path
              clipRule="evenodd"
              d={svgPaths.p232c9a40}
              fill="var(--fill-0, #CCCCCC)"
              fillRule="evenodd"
            />
            <path d={svgPaths.p30c4d080} fill="var(--fill-0, #CCCCCC)" />
            <path
              clipRule="evenodd"
              d={svgPaths.p2f170e40}
              fill="var(--fill-0, #CCCCCC)"
              fillRule="evenodd"
            />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Linkedin() {
  return (
    <div className="relative shrink-0 size-5" data-name="linkedin">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="linkedin">
          <path
            d={svgPaths.p214f4800}
            fill="var(--fill-0, #CCCCCC)"
            id="vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame24() {
  return (
    <div className="box-border content-stretch flex flex-row gap-3 items-center justify-start p-0 relative shrink-0">
      <Behance />
      <Instagram />
      <Linkedin />
    </div>
  );
}

function Frame1() {
  return (
    <div className="absolute box-border content-stretch flex flex-row items-center justify-between left-1/2 p-[16px] top-[75px] translate-x-[-50%] w-[393px]">
      <Group1 />
      <Frame24 />
    </div>
  );
}

function Frame2() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-4 items-center justify-center leading-[0] px-4 py-0 relative text-center w-full">
          <div className="font-['Geist:SemiBold',_sans-serif] font-semibold relative shrink-0 text-[#ffffff] text-[0px] w-full">
            <p className="leading-[40px] text-[32px]">
              <span className="font-['Geist:SemiBold',_sans-serif] font-semibold">{`Hi there! I’m `}</span>
              <span className="font-['Geist:SemiBold',_sans-serif] font-semibold text-[#ffffff]">
                Facu
              </span>
              <span className="font-['Geist:SemiBold',_sans-serif] font-semibold">{`, your next `}</span>
              <span className="font-['Geist:ExtraLight_Italic',_sans-serif] not-italic">
                product designer
              </span>
              <span className="font-['Geist:SemiBold',_sans-serif] font-semibold">
                .
              </span>
            </p>
          </div>
          <div className="font-['Geist:Regular',_sans-serif] font-normal relative shrink-0 text-[16px] text-[rgba(255,255,255,0.9)] w-full">
            <p className="block leading-[24px]">
              Specializing in intuitive wireframes, interactive prototypes, and
              visual identities that captivate global audiences. Ready to
              elevate your brand?
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function ArrowDown() {
  return (
    <div className="relative shrink-0 size-4" data-name="Arrow down">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="Arrow down">
          <path
            d={svgPaths.p14089660}
            id="Icon"
            stroke="var(--stroke-0, #0A0A0A)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div
      className="bg-[#ededed] box-border content-stretch flex flex-row gap-2.5 h-12 items-center justify-center overflow-clip px-3 py-0 relative rounded-lg shrink-0"
      data-name="Button"
    >
      <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[16px] text-center text-neutral-950 text-nowrap">
        <p className="block leading-[24px] whitespace-pre">Get a quote</p>
      </div>
      <ArrowDown />
    </div>
  );
}

function Frame4() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-8 items-center justify-start left-1/2 p-0 top-[321px] translate-x-[-50%] w-[393px]">
      <Frame2 />
      <Button />
    </div>
  );
}

function Frame10() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-center justify-center leading-[0] p-0 relative shrink-0 text-center w-full">
      <div className="font-['Geist:SemiBold',_sans-serif] font-semibold relative shrink-0 text-[#ffffff] text-[0px] w-full">
        <p className="leading-[32px] text-[24px]">
          <span>{`Services That `}</span>
          <span className="font-['Geist:ExtraLight_Italic',_sans-serif] not-italic">{`Drive `}</span>
          <span className="font-['Geist:ExtraLight_Italic',_sans-serif] not-italic text-[#ffffff]">
            Results
          </span>
        </p>
      </div>
      <div className="font-['Geist:Regular',_sans-serif] font-normal relative shrink-0 text-[16px] text-[rgba(255,255,255,0.8)] w-full">
        <p className="block leading-[24px]">
          Comprehensive design solutions tailored to elevate your brand and
          engage your audience
        </p>
      </div>
    </div>
  );
}

function Phone01() {
  return (
    <div className="relative shrink-0 size-6" data-name="phone-01">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="phone-01">
          <path
            d={svgPaths.p21691300}
            id="Icon"
            stroke="var(--stroke-0, white)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
          />
        </g>
      </svg>
    </div>
  );
}

function Frame8() {
  return (
    <div className="bg-[#7746d7] box-border content-stretch flex flex-row gap-2.5 items-center justify-start p-[12px] relative rounded-[9999px] shrink-0">
      <Phone01 />
    </div>
  );
}

function Frame20() {
  return (
    <div className="box-border content-stretch flex flex-col gap-1 items-center justify-start p-0 relative shrink-0 w-full">
      <div className="font-['Geist:SemiBold',_sans-serif] font-semibold relative shrink-0 text-[#ffffff] text-[20px] text-nowrap">
        <p className="block leading-[26px] whitespace-pre">UX/UI Design</p>
      </div>
      <div
        className="font-['Geist:Medium',_sans-serif] font-medium min-w-full relative shrink-0 text-[#7746d7] text-[14px]"
        style={{ width: "min-content" }}
      >
        <p className="block leading-[20px]">Figma, Justinmind</p>
      </div>
    </div>
  );
}

function Frame7() {
  return (
    <div className="box-border content-stretch flex flex-col gap-4 items-center justify-center leading-[0] p-0 relative shrink-0 text-center w-full">
      <Frame20 />
      <div className="font-['Geist:Regular',_sans-serif] font-normal relative shrink-0 text-[14px] text-[rgba(255,255,255,0.8)] w-full">
        <p className="block leading-[20px]">
          Intuitive wireframes, user flows, and interactive prototypes in Figma,
          backed by UX expertise in user research, A/B testing, and
          accessibility optimization. I focus on seamless experiences that boost
          conversions and keep users hooked.
        </p>
      </div>
    </div>
  );
}

function Frame3() {
  return (
    <div className="bg-neutral-950 relative rounded-lg shrink-0 w-full">
      <div className="absolute border-[0.5px] border-[rgba(209,209,209,0.3)] border-solid inset-0 pointer-events-none rounded-lg" />
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-6 items-center justify-center p-[16px] relative w-full">
          <Frame8 />
          <Frame7 />
        </div>
      </div>
    </div>
  );
}

function Frame9() {
  return (
    <div className="bg-[#7746d7] box-border content-stretch flex flex-row gap-2.5 items-center justify-start p-[12px] relative rounded-[9999px] shrink-0">
      <div
        className="overflow-clip relative shrink-0 size-6"
        data-name="palette"
      >
        <Palette />
      </div>
    </div>
  );
}

function Frame12() {
  return (
    <div className="box-border content-stretch flex flex-col gap-1 items-start justify-start p-0 relative shrink-0 w-full">
      <div className="font-['Geist:SemiBold',_sans-serif] font-semibold relative shrink-0 text-[#ffffff] text-[20px] w-full">
        <p className="block leading-[26px]">Graphic Design</p>
      </div>
      <div className="font-['Geist:Medium',_sans-serif] font-medium relative shrink-0 text-[#7746d7] text-[14px] w-full">
        <p className="block leading-[20px]">
          Adobe Illustrator, Photoshop, MidJourney
        </p>
      </div>
    </div>
  );
}

function Frame19() {
  return (
    <div className="box-border content-stretch flex flex-col gap-4 items-start justify-start leading-[0] p-0 relative shrink-0 text-center w-full">
      <Frame12 />
      <div className="font-['Geist:Regular',_sans-serif] font-normal relative shrink-0 text-[14px] text-[rgba(255,255,255,0.8)] w-full">
        <p className="block leading-[20px]">
          Crafting captivating logos, branding visuals, and digital assets using
          Adobe Illustrator, Photoshop, and MidJourney. Backed by expertise in
          color theory, typography, and trend-forward designs that make your
          brand stand out and drive engagement.
        </p>
      </div>
    </div>
  );
}

function Frame27() {
  return (
    <div className="bg-neutral-950 relative rounded-lg shrink-0 w-full">
      <div className="absolute border-[0.5px] border-[rgba(209,209,209,0.3)] border-solid inset-0 pointer-events-none rounded-lg" />
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-6 items-center justify-center p-[16px] relative w-full">
          <Frame9 />
          <Frame19 />
        </div>
      </div>
    </div>
  );
}

function Frame21() {
  return (
    <div className="box-border content-stretch flex flex-col gap-8 items-start justify-start p-0 relative shrink-0 w-full">
      <Frame3 />
      <Frame27 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-col items-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-12 items-center justify-start px-4 py-0 relative w-full">
          <Frame10 />
          <Frame21 />
        </div>
      </div>
    </div>
  );
}

function Frame28() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-center justify-center leading-[0] p-0 relative shrink-0 text-center w-full">
      <div className="font-['Geist:SemiBold',_sans-serif] font-semibold relative shrink-0 text-[#ffffff] text-[0px] w-full">
        <p className="leading-[32px] text-[24px]">
          <span>{`Ready to `}</span>
          <span className="font-['Geist:SemiBold',_sans-serif] font-semibold text-[#7746d7]">
            Upgrade
          </span>
          <span className="text-[#7746d7]"> </span>
          <span className="font-['Geist:SemiBold',_sans-serif] font-semibold text-[#ffffff]">
            Your Brand
          </span>
          ?
        </p>
      </div>
      <div className="font-['Geist:Regular',_sans-serif] font-normal relative shrink-0 text-[16px] text-[rgba(255,255,255,0.8)] w-full">
        <p className="block leading-[24px]">{`Let's discuss your project and create something amazing together. Get in touch for a personalized consultation.`}</p>
      </div>
    </div>
  );
}

function ArrowDown1() {
  return (
    <div className="relative shrink-0 size-4" data-name="Arrow down">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="Arrow down">
          <path
            d={svgPaths.p14089660}
            id="Icon"
            stroke="var(--stroke-0, white)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div
      className="bg-neutral-950 h-10 relative rounded-md shrink-0 w-full"
      data-name="Button"
    >
      <div className="flex flex-row items-center justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-10 items-center justify-center px-3 py-0 relative w-full">
          <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#ededed] text-[14px] text-center text-nowrap">
            <p className="block leading-[20px] whitespace-pre">
              Start your project today
            </p>
          </div>
          <ArrowDown1 />
        </div>
      </div>
      <div className="absolute border border-[#2e2e2e] border-solid inset-0 pointer-events-none rounded-md" />
    </div>
  );
}

function Frame14() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2.5 items-start justify-start p-0 relative shrink-0 w-full">
      <Button1 />
    </div>
  );
}

function Frame18() {
  return (
    <div className="box-border content-stretch flex flex-col gap-6 items-center justify-start p-0 relative shrink-0 w-full">
      <Frame28 />
      <Frame14 />
    </div>
  );
}

function Frame29() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-col items-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-6 items-center justify-start px-4 py-0 relative w-full">
          <Frame18 />
        </div>
      </div>
    </div>
  );
}

function Frame30() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-center justify-center leading-[0] p-0 relative shrink-0 text-center w-full">
      <div className="font-['Geist:SemiBold',_sans-serif] font-semibold relative shrink-0 text-[#ffffff] text-[0px] w-full">
        <p className="leading-[32px] text-[24px]">
          <span>{`Featured `}</span>
          <span className="text-[#ffffff]">Projects</span>
        </p>
      </div>
      <div className="font-['Geist:Regular',_sans-serif] font-normal relative shrink-0 text-[16px] text-[rgba(255,255,255,0.8)] w-full">
        <p className="block leading-[24px]">
          A showcase of successful projects delivered for clients across
          different industries and continents.
        </p>
      </div>
    </div>
  );
}

function Badge() {
  return (
    <div
      className="absolute bg-[#1f1f1f] box-border content-stretch flex flex-row gap-1 h-6 items-center justify-center overflow-clip px-2.5 py-0 right-[17px] rounded-[32px] top-4"
      data-name="Badge"
    >
      <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#ededed] text-[12px] text-center text-nowrap">
        <p className="block leading-[12px] whitespace-pre">UX/UI Project</p>
      </div>
    </div>
  );
}

function Frame11() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2.5 items-start justify-start p-0 relative shrink-0 w-full">
      <div
        className="aspect-[361/174] bg-center bg-cover bg-no-repeat rounded-tl-[8px] rounded-tr-[8px] shrink-0 w-full"
        data-name="d8e6eb6b345ada088e2448947c483ab4 2"
        style={{
          backgroundImage: `url('${imgD8E6Eb6B345Ada088E2448947C483Ab42}')`,
        }}
      />
      <Badge />
    </div>
  );
}

function Frame31() {
  return (
    <div className="box-border content-stretch flex flex-col gap-1 items-start justify-start p-0 relative shrink-0 w-full">
      <div className="font-['Geist:SemiBold',_sans-serif] font-semibold leading-[0] relative shrink-0 text-[#ffffff] text-[20px] text-left text-nowrap">
        <p className="block leading-[26px] whitespace-pre">Dashboard for SHM</p>
      </div>
    </div>
  );
}

function Frame13() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full">
      <Frame31 />
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(255,255,255,0.8)] text-left w-full">
        <p className="block leading-[20px]">
          Complete mobile app redesign focusing on user experience and
          conversion optimization
        </p>
      </div>
    </div>
  );
}

function Frame32() {
  return (
    <div className="box-border content-stretch flex flex-row gap-1.5 items-center justify-center p-0 relative shrink-0">
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Figma</p>
      </div>
      <div className="relative shrink-0 size-1">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 4 4"
        >
          <circle
            cx="2"
            cy="2"
            fill="var(--fill-0, #D1D1D1)"
            fillOpacity="0.7"
            id="Ellipse 1"
            r="2"
          />
        </svg>
      </div>
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Prototyping</p>
      </div>
      <div className="relative shrink-0 size-1">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 4 4"
        >
          <circle
            cx="2"
            cy="2"
            fill="var(--fill-0, #D1D1D1)"
            fillOpacity="0.7"
            id="Ellipse 1"
            r="2"
          />
        </svg>
      </div>
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">User Research</p>
      </div>
    </div>
  );
}

function Frame33() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full">
      <Frame13 />
      <Frame32 />
    </div>
  );
}

function ArrowUp3() {
  return (
    <div className="relative shrink-0 size-4" data-name="arrow-up">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="arrow-up">
          <path
            d={svgPaths.p2b9ec400}
            id="Vector"
            stroke="var(--stroke-0, #0A0A0A)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="1.33333"
          />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div
      className="bg-[#ededed] h-10 relative rounded-md shrink-0 w-full"
      data-name="Button"
    >
      <div className="flex flex-row items-center justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-10 items-center justify-center px-3 py-0 relative w-full">
          <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[14px] text-center text-neutral-950 text-nowrap">
            <p className="block leading-[20px] whitespace-pre">
              See on Behance
            </p>
          </div>
          <ArrowUp3 />
        </div>
      </div>
    </div>
  );
}

function Frame34() {
  return (
    <div className="relative rounded-lg shrink-0 w-full">
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-6 items-center justify-center p-[16px] relative w-full">
          <Frame33 />
          <Button2 />
        </div>
      </div>
    </div>
  );
}

function Frame35() {
  return (
    <div className="bg-neutral-950 box-border content-stretch flex flex-col items-center justify-start p-0 relative rounded-lg shrink-0 w-full">
      <div className="absolute border-[0.5px] border-[rgba(209,209,209,0.3)] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      <Frame11 />
      <Frame34 />
    </div>
  );
}

function Badge1() {
  return (
    <div
      className="absolute bg-[#1f1f1f] box-border content-stretch flex flex-row gap-1 h-6 items-center justify-center overflow-clip px-2.5 py-0 right-[17px] rounded-[32px] top-4"
      data-name="Badge"
    >
      <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#ededed] text-[12px] text-center text-nowrap">
        <p className="block leading-[12px] whitespace-pre">UX/UI Project</p>
      </div>
    </div>
  );
}

function Frame36() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2.5 items-start justify-start p-0 relative shrink-0 w-full">
      <div
        className="aspect-[361/174] bg-center bg-cover bg-no-repeat rounded-tl-[8px] rounded-tr-[8px] shrink-0 w-full"
        data-name="d8e6eb6b345ada088e2448947c483ab4 2"
        style={{
          backgroundImage: `url('${imgD8E6Eb6B345Ada088E2448947C483Ab43}')`,
        }}
      />
      <Badge1 />
    </div>
  );
}

function Frame37() {
  return (
    <div className="box-border content-stretch flex flex-col gap-1 items-start justify-start p-0 relative shrink-0 w-full">
      <div className="font-['Geist:SemiBold',_sans-serif] font-semibold leading-[0] relative shrink-0 text-[#ffffff] text-[20px] text-left text-nowrap">
        <p className="block leading-[26px] whitespace-pre">
          Full website for CompraJusta
        </p>
      </div>
    </div>
  );
}

function Frame38() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full">
      <Frame37 />
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(255,255,255,0.8)] text-left w-full">
        <p className="block leading-[20px]">
          Complete mobile app redesign focusing on user experience and
          conversion optimization
        </p>
      </div>
    </div>
  );
}

function Frame39() {
  return (
    <div className="box-border content-stretch flex flex-row gap-1.5 items-center justify-center p-0 relative shrink-0">
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Figma</p>
      </div>
      <div className="relative shrink-0 size-1">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 4 4"
        >
          <circle
            cx="2"
            cy="2"
            fill="var(--fill-0, #D1D1D1)"
            fillOpacity="0.7"
            id="Ellipse 1"
            r="2"
          />
        </svg>
      </div>
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Prototyping</p>
      </div>
      <div className="relative shrink-0 size-1">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 4 4"
        >
          <circle
            cx="2"
            cy="2"
            fill="var(--fill-0, #D1D1D1)"
            fillOpacity="0.7"
            id="Ellipse 1"
            r="2"
          />
        </svg>
      </div>
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">User Research</p>
      </div>
    </div>
  );
}

function Frame40() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full">
      <Frame38 />
      <Frame39 />
    </div>
  );
}

function ArrowUp5() {
  return (
    <div className="relative shrink-0 size-4" data-name="arrow-up">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="arrow-up">
          <path
            d={svgPaths.p2b9ec400}
            id="Vector"
            stroke="var(--stroke-0, #0A0A0A)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="1.33333"
          />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div
      className="bg-[#ededed] h-10 relative rounded-md shrink-0 w-full"
      data-name="Button"
    >
      <div className="flex flex-row items-center justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-10 items-center justify-center px-3 py-0 relative w-full">
          <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[14px] text-center text-neutral-950 text-nowrap">
            <p className="block leading-[20px] whitespace-pre">
              See on Behance
            </p>
          </div>
          <ArrowUp5 />
        </div>
      </div>
    </div>
  );
}

function Frame41() {
  return (
    <div className="relative rounded-lg shrink-0 w-full">
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-6 items-center justify-center p-[16px] relative w-full">
          <Frame40 />
          <Button3 />
        </div>
      </div>
    </div>
  );
}

function Frame16() {
  return (
    <div className="bg-neutral-950 box-border content-stretch flex flex-col items-center justify-start p-0 relative rounded-lg shrink-0 w-full">
      <Frame36 />
      <Frame41 />
    </div>
  );
}

function Badge2() {
  return (
    <div
      className="absolute bg-[#1f1f1f] box-border content-stretch flex flex-row gap-1 h-6 items-center justify-center overflow-clip px-2.5 py-0 right-[17px] rounded-[32px] top-4"
      data-name="Badge"
    >
      <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#ededed] text-[12px] text-center text-nowrap">
        <p className="block leading-[12px] whitespace-pre">UX/UI Project</p>
      </div>
    </div>
  );
}

function Frame42() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2.5 items-start justify-start p-0 relative shrink-0 w-full">
      <div
        className="aspect-[361/174] bg-center bg-cover bg-no-repeat rounded-tl-[8px] rounded-tr-[8px] shrink-0 w-full"
        data-name="d8e6eb6b345ada088e2448947c483ab4 2"
        style={{
          backgroundImage: `url('${imgD8E6Eb6B345Ada088E2448947C483Ab44}')`,
        }}
      />
      <Badge2 />
    </div>
  );
}

function Frame43() {
  return (
    <div className="box-border content-stretch flex flex-col gap-1 items-start justify-start p-0 relative shrink-0 w-full">
      <div className="font-['Geist:SemiBold',_sans-serif] font-semibold leading-[0] relative shrink-0 text-[#ffffff] text-[20px] text-left w-full">
        <p className="block leading-[26px]">Modern landing page for Klamad</p>
      </div>
    </div>
  );
}

function Frame44() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full">
      <Frame43 />
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(255,255,255,0.8)] text-left w-full">
        <p className="block leading-[20px]">
          Complete mobile app redesign focusing on user experience and
          conversion optimization
        </p>
      </div>
    </div>
  );
}

function Frame45() {
  return (
    <div className="box-border content-stretch flex flex-row gap-1.5 items-center justify-center p-0 relative shrink-0">
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Figma</p>
      </div>
      <div className="relative shrink-0 size-1">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 4 4"
        >
          <circle
            cx="2"
            cy="2"
            fill="var(--fill-0, #D1D1D1)"
            fillOpacity="0.7"
            id="Ellipse 1"
            r="2"
          />
        </svg>
      </div>
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Prototyping</p>
      </div>
      <div className="relative shrink-0 size-1">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 4 4"
        >
          <circle
            cx="2"
            cy="2"
            fill="var(--fill-0, #D1D1D1)"
            fillOpacity="0.7"
            id="Ellipse 1"
            r="2"
          />
        </svg>
      </div>
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">User Research</p>
      </div>
    </div>
  );
}

function Frame46() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full">
      <Frame44 />
      <Frame45 />
    </div>
  );
}

function ArrowUp7() {
  return (
    <div className="relative shrink-0 size-4" data-name="arrow-up">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="arrow-up">
          <path
            d={svgPaths.p2b9ec400}
            id="Vector"
            stroke="var(--stroke-0, #0A0A0A)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="1.33333"
          />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div
      className="bg-[#ededed] h-10 relative rounded-md shrink-0 w-full"
      data-name="Button"
    >
      <div className="flex flex-row items-center justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-10 items-center justify-center px-3 py-0 relative w-full">
          <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[14px] text-center text-neutral-950 text-nowrap">
            <p className="block leading-[20px] whitespace-pre">
              See on Behance
            </p>
          </div>
          <ArrowUp7 />
        </div>
      </div>
    </div>
  );
}

function Frame47() {
  return (
    <div className="relative rounded-lg shrink-0 w-full">
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-6 items-center justify-center p-[16px] relative w-full">
          <Frame46 />
          <Button4 />
        </div>
      </div>
    </div>
  );
}

function Frame15() {
  return (
    <div className="bg-neutral-950 box-border content-stretch flex flex-col items-center justify-start p-0 relative rounded-lg shrink-0 w-full">
      <Frame42 />
      <Frame47 />
    </div>
  );
}

function Badge3() {
  return (
    <div
      className="absolute bg-[#1f1f1f] box-border content-stretch flex flex-row gap-1 h-6 items-center justify-center overflow-clip px-2.5 py-0 right-[17px] rounded-[32px] top-4"
      data-name="Badge"
    >
      <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#ededed] text-[12px] text-center text-nowrap">
        <p className="block leading-[12px] whitespace-pre">Graphic Design</p>
      </div>
    </div>
  );
}

function Frame48() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2.5 items-start justify-start p-0 relative shrink-0 w-full">
      <div
        className="aspect-[361/174] bg-center bg-cover bg-no-repeat rounded-tl-[8px] rounded-tr-[8px] shrink-0 w-full"
        data-name="d8e6eb6b345ada088e2448947c483ab4 2"
        style={{
          backgroundImage: `url('${imgD8E6Eb6B345Ada088E2448947C483Ab45}')`,
        }}
      />
      <Badge3 />
    </div>
  );
}

function Frame49() {
  return (
    <div className="box-border content-stretch flex flex-col gap-1 items-start justify-start p-0 relative shrink-0 w-full">
      <div className="font-['Geist:SemiBold',_sans-serif] font-semibold leading-[0] relative shrink-0 text-[#ffffff] text-[20px] text-left w-full">
        <p className="block leading-[26px]">Brand Identity for Hoxi</p>
      </div>
    </div>
  );
}

function Frame50() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full">
      <Frame49 />
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(255,255,255,0.8)] text-left w-full">
        <p className="block leading-[20px]">
          Complete mobile app redesign focusing on user experience and
          conversion optimization
        </p>
      </div>
    </div>
  );
}

function Frame51() {
  return (
    <div className="box-border content-stretch flex flex-row gap-1.5 items-center justify-center p-0 relative shrink-0">
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Figma</p>
      </div>
      <div className="relative shrink-0 size-1">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 4 4"
        >
          <circle
            cx="2"
            cy="2"
            fill="var(--fill-0, #D1D1D1)"
            fillOpacity="0.7"
            id="Ellipse 1"
            r="2"
          />
        </svg>
      </div>
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Prototyping</p>
      </div>
      <div className="relative shrink-0 size-1">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 4 4"
        >
          <circle
            cx="2"
            cy="2"
            fill="var(--fill-0, #D1D1D1)"
            fillOpacity="0.7"
            id="Ellipse 1"
            r="2"
          />
        </svg>
      </div>
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">User Research</p>
      </div>
    </div>
  );
}

function Frame52() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full">
      <Frame50 />
      <Frame51 />
    </div>
  );
}

function ArrowUp9() {
  return (
    <div className="relative shrink-0 size-4" data-name="arrow-up">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="arrow-up">
          <path
            d={svgPaths.p2b9ec400}
            id="Vector"
            stroke="var(--stroke-0, #0A0A0A)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="1.33333"
          />
        </g>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div
      className="bg-[#ededed] h-10 relative rounded-md shrink-0 w-full"
      data-name="Button"
    >
      <div className="flex flex-row items-center justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-10 items-center justify-center px-3 py-0 relative w-full">
          <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[14px] text-center text-neutral-950 text-nowrap">
            <p className="block leading-[20px] whitespace-pre">
              See on Behance
            </p>
          </div>
          <ArrowUp9 />
        </div>
      </div>
    </div>
  );
}

function Frame53() {
  return (
    <div className="relative rounded-lg shrink-0 w-full">
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-6 items-center justify-center p-[16px] relative w-full">
          <Frame52 />
          <Button5 />
        </div>
      </div>
    </div>
  );
}

function Frame17() {
  return (
    <div className="bg-neutral-950 box-border content-stretch flex flex-col items-center justify-start p-0 relative rounded-lg shrink-0 w-full">
      <Frame48 />
      <Frame53 />
    </div>
  );
}

function Badge4() {
  return (
    <div
      className="absolute bg-[#1f1f1f] box-border content-stretch flex flex-row gap-1 h-6 items-center justify-center overflow-clip px-2.5 py-0 right-[17px] rounded-[32px] top-4"
      data-name="Badge"
    >
      <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#ededed] text-[12px] text-center text-nowrap">
        <p className="block leading-[12px] whitespace-pre">UX/UI Project</p>
      </div>
    </div>
  );
}

function Frame54() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2.5 items-start justify-start p-0 relative shrink-0 w-full">
      <div
        className="aspect-[361/174] bg-[0%_18.76%] bg-no-repeat bg-size-[100%_155.64%] rounded-tl-[8px] rounded-tr-[8px] shrink-0 w-full"
        data-name="d8e6eb6b345ada088e2448947c483ab4 2"
        style={{
          backgroundImage: `url('${imgD8E6Eb6B345Ada088E2448947C483Ab46}')`,
        }}
      />
      <Badge4 />
    </div>
  );
}

function Frame55() {
  return (
    <div className="box-border content-stretch flex flex-col gap-1 items-start justify-start p-0 relative shrink-0 w-full">
      <div className="font-['Geist:SemiBold',_sans-serif] font-semibold leading-[0] relative shrink-0 text-[#ffffff] text-[20px] text-left w-full">
        <p className="block leading-[26px]">Landing page for WindsorGroup</p>
      </div>
    </div>
  );
}

function Frame56() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full">
      <Frame55 />
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(255,255,255,0.8)] text-left w-full">
        <p className="block leading-[20px]">
          Complete mobile app redesign focusing on user experience and
          conversion optimization
        </p>
      </div>
    </div>
  );
}

function Frame57() {
  return (
    <div className="box-border content-stretch flex flex-row gap-1.5 items-center justify-center p-0 relative shrink-0">
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Figma</p>
      </div>
      <div className="relative shrink-0 size-1">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 4 4"
        >
          <circle
            cx="2"
            cy="2"
            fill="var(--fill-0, #D1D1D1)"
            fillOpacity="0.7"
            id="Ellipse 1"
            r="2"
          />
        </svg>
      </div>
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Prototyping</p>
      </div>
      <div className="relative shrink-0 size-1">
        <svg
          className="block size-full"
          fill="none"
          preserveAspectRatio="none"
          viewBox="0 0 4 4"
        >
          <circle
            cx="2"
            cy="2"
            fill="var(--fill-0, #D1D1D1)"
            fillOpacity="0.7"
            id="Ellipse 1"
            r="2"
          />
        </svg>
      </div>
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[14px] text-[rgba(209,209,209,0.7)] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">User Research</p>
      </div>
    </div>
  );
}

function Frame58() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full">
      <Frame56 />
      <Frame57 />
    </div>
  );
}

function ArrowUp11() {
  return (
    <div className="relative shrink-0 size-4" data-name="arrow-up">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="arrow-up">
          <path
            d={svgPaths.p2b9ec400}
            id="Vector"
            stroke="var(--stroke-0, #0A0A0A)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="1.33333"
          />
        </g>
      </svg>
    </div>
  );
}

function Button6() {
  return (
    <div
      className="bg-[#ededed] h-10 relative rounded-md shrink-0 w-full"
      data-name="Button"
    >
      <div className="flex flex-row items-center justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-10 items-center justify-center px-3 py-0 relative w-full">
          <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[14px] text-center text-neutral-950 text-nowrap">
            <p className="block leading-[20px] whitespace-pre">
              See on Behance
            </p>
          </div>
          <ArrowUp11 />
        </div>
      </div>
    </div>
  );
}

function Frame59() {
  return (
    <div className="relative rounded-lg shrink-0 w-full">
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-6 items-center justify-center p-[16px] relative w-full">
          <Frame58 />
          <Button6 />
        </div>
      </div>
    </div>
  );
}

function Frame60() {
  return (
    <div className="bg-neutral-950 box-border content-stretch flex flex-col items-center justify-start p-0 relative rounded-lg shrink-0 w-full">
      <div className="absolute border-[0.5px] border-[rgba(209,209,209,0.3)] border-solid inset-[-0.5px] pointer-events-none rounded-[8.5px]" />
      <Frame54 />
      <Frame59 />
    </div>
  );
}

function Frame23() {
  return (
    <div className="box-border content-stretch flex flex-col gap-8 items-start justify-start p-0 relative shrink-0 w-full">
      <Frame35 />
      <Frame16 />
      <Frame15 />
      <Frame17 />
      <Frame60 />
    </div>
  );
}

function Frame6() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-col items-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-6 items-center justify-start px-4 py-0 relative w-full">
          <Frame30 />
          <Frame23 />
        </div>
      </div>
    </div>
  );
}

function Frame61() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-start justify-center leading-[0] p-0 relative shrink-0 text-left w-full">
      <div className="font-['Geist:SemiBold',_sans-serif] font-semibold relative shrink-0 text-[#ffffff] text-[24px] w-full">
        <p className="block leading-[32px]">Get a personalized quote</p>
      </div>
      <div className="font-['Geist:Regular',_sans-serif] font-normal relative shrink-0 text-[16px] text-[rgba(255,255,255,0.8)] w-full">
        <p className="block leading-[24px]">
          Subscribe to get design tips, industry insights, and exclusive project
          updates.
        </p>
      </div>
    </div>
  );
}

function Input() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-start justify-start p-0 relative shrink-0 w-full"
      data-name="_Input"
    >
      <div className="basis-0 font-['Geist:Regular',_sans-serif] font-normal grow leading-[0] min-h-px min-w-px relative shrink-0 text-[#888888] text-[14px] text-left">
        <p className="block leading-[20px]">Your name</p>
      </div>
    </div>
  );
}

function Input1() {
  return (
    <div
      className="basis-0 grow h-10 min-h-px min-w-px relative shrink-0"
      data-name="Input"
    >
      <div className="flex flex-col justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 h-10 items-start justify-center px-3 py-0 relative w-full">
          <Input />
        </div>
      </div>
    </div>
  );
}

function Input2() {
  return (
    <div
      className="bg-neutral-950 h-10 relative rounded-md shrink-0 w-full"
      data-name="Input"
    >
      <div className="box-border content-stretch flex flex-row h-10 items-center justify-start overflow-clip p-0 relative w-full">
        <Input1 />
      </div>
      <div className="absolute border border-[#2e2e2e] border-solid inset-0 pointer-events-none rounded-md" />
    </div>
  );
}

function Input3() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Input"
    >
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[#a1a1a1] text-[13px] text-left text-nowrap">
        <p className="block leading-[16px] whitespace-pre">Name*</p>
      </div>
      <Input2 />
    </div>
  );
}

function Input4() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-start justify-start p-0 relative shrink-0 w-full"
      data-name="_Input"
    >
      <div className="basis-0 font-['Geist:Regular',_sans-serif] font-normal grow leading-[0] min-h-px min-w-px relative shrink-0 text-[#888888] text-[14px] text-left">
        <p className="block leading-[20px]">Project Title</p>
      </div>
    </div>
  );
}

function Input5() {
  return (
    <div
      className="basis-0 grow h-10 min-h-px min-w-px relative shrink-0"
      data-name="Input"
    >
      <div className="flex flex-col justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 h-10 items-start justify-center px-3 py-0 relative w-full">
          <Input4 />
        </div>
      </div>
    </div>
  );
}

function Input6() {
  return (
    <div
      className="bg-neutral-950 h-10 relative rounded-md shrink-0 w-full"
      data-name="Input"
    >
      <div className="box-border content-stretch flex flex-row h-10 items-center justify-start overflow-clip p-0 relative w-full">
        <Input5 />
      </div>
      <div className="absolute border border-[#2e2e2e] border-solid inset-0 pointer-events-none rounded-md" />
    </div>
  );
}

function Input7() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Input"
    >
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[#a1a1a1] text-[13px] text-left text-nowrap">
        <p className="block leading-[16px] whitespace-pre">Project Title*</p>
      </div>
      <Input6 />
    </div>
  );
}

function Input8() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row gap-2 grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="_Input"
    >
      <div className="basis-0 font-['Geist:Regular',_sans-serif] font-normal grow leading-[0] min-h-px min-w-px relative shrink-0 text-[#888888] text-[14px] text-left">
        <p className="block leading-[20px]">E - Commerce Website</p>
      </div>
    </div>
  );
}

function ChevronDown() {
  return (
    <div className="relative shrink-0 size-[18px]" data-name="chevron-down">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 18 18"
      >
        <g id="chevron-down">
          <path
            d="M4.5 6.75L9 11.25L13.5 6.75"
            id="Vector"
            stroke="var(--stroke-0, #A1A1A1)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="1.5"
          />
        </g>
      </svg>
    </div>
  );
}

function Select() {
  return (
    <div
      className="bg-neutral-950 h-10 relative rounded-[5px] shrink-0 w-full"
      data-name="Select"
    >
      <div className="flex flex-row items-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2 h-10 items-center justify-start px-3 py-2 relative w-full">
          <Input8 />
          <ChevronDown />
        </div>
      </div>
      <div className="absolute border border-[#2e2e2e] border-solid inset-0 pointer-events-none rounded-[5px]" />
    </div>
  );
}

function Select1() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Select"
    >
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[#a1a1a1] text-[13px] text-left text-nowrap">
        <p className="block leading-[16px] whitespace-pre">Project Type*</p>
      </div>
      <Select />
    </div>
  );
}

function Input9() {
  return (
    <div
      className="bg-neutral-950 min-h-[100px] relative rounded-md shrink-0 w-full"
      data-name="Input"
    >
      <div className="min-h-inherit overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row items-start justify-start min-h-inherit px-3 py-2.5 relative w-full">
          <div className="basis-0 font-['Geist:Regular',_sans-serif] font-normal grow leading-[0] min-h-px min-w-px relative self-stretch shrink-0 text-[#a1a1a1] text-[13px] text-left">
            <p className="block leading-[16px]">(Máx 300 characters)</p>
          </div>
        </div>
      </div>
      <div className="absolute border border-[rgba(255,255,255,0.02)] border-solid inset-0 pointer-events-none rounded-md" />
    </div>
  );
}

function Textarea() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Textarea"
    >
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[#a1a1a1] text-[13px] text-left text-nowrap">
        <p className="block leading-[16px] whitespace-pre">Description</p>
      </div>
      <Input9 />
    </div>
  );
}

function Div() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-1 items-start justify-start p-0 relative shrink-0"
      data-name="Div"
    >
      <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#ededed] text-[14px] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Yes</p>
      </div>
    </div>
  );
}

function Check() {
  return (
    <div className="relative shrink-0 size-4" data-name="check">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="check">
          <path
            d={svgPaths.p39be50}
            id="Vector"
            stroke="var(--stroke-0, black)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="1.33333"
          />
        </g>
      </svg>
    </div>
  );
}

function Checkbox() {
  return (
    <div
      className="bg-[#8d5ced] box-border content-stretch flex flex-row items-center justify-center overflow-clip p-[2px] relative rounded shrink-0 size-5"
      data-name="Checkbox"
    >
      <Check />
    </div>
  );
}

function Div1() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-start justify-start p-0 relative shrink-0"
      data-name="Div"
    >
      <Checkbox />
    </div>
  );
}

function Checkbox1() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0"
      data-name="Checkbox"
    >
      <Div1 />
    </div>
  );
}

function Choicebox() {
  return (
    <div
      className="basis-0 bg-[rgba(119,70,215,0.3)] grow min-h-px min-w-px relative rounded-md shrink-0"
      data-name="Choicebox"
    >
      <div className="flex flex-row items-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row items-center justify-between p-[12px] relative w-full">
          <Div />
          <Checkbox1 />
        </div>
      </div>
      <div className="absolute border border-[#7746d7] border-solid inset-0 pointer-events-none rounded-md" />
    </div>
  );
}

function Div2() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-1 items-start justify-start p-0 relative shrink-0"
      data-name="Div"
    >
      <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#ededed] text-[14px] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">No</p>
      </div>
    </div>
  );
}

function Checkbox2() {
  return (
    <div
      className="bg-[#1a1a1a] relative rounded shrink-0 size-5"
      data-name="Checkbox"
    >
      <div className="box-border content-stretch flex flex-row items-center justify-center overflow-clip p-[2px] size-5" />
      <div className="absolute border border-[#8f8f8f] border-solid inset-0 pointer-events-none rounded" />
    </div>
  );
}

function Div3() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-start justify-start p-0 relative shrink-0"
      data-name="Div"
    >
      <Checkbox2 />
    </div>
  );
}

function Checkbox3() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0"
      data-name="Checkbox"
    >
      <Div3 />
    </div>
  );
}

function Choicebox1() {
  return (
    <div
      className="basis-0 bg-[#000000] grow min-h-px min-w-px relative rounded-md shrink-0"
      data-name="Choicebox"
    >
      <div className="flex flex-row items-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row items-center justify-between p-[12px] relative w-full">
          <Div2 />
          <Checkbox3 />
        </div>
      </div>
      <div className="absolute border border-[#454545] border-solid inset-0 pointer-events-none rounded-md" />
    </div>
  );
}

function Frame25() {
  return (
    <div className="box-border content-stretch flex flex-row gap-3 items-start justify-start p-0 relative shrink-0 w-full">
      <Choicebox />
      <Choicebox1 />
    </div>
  );
}

function Frame26() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-start justify-center p-0 relative shrink-0 w-full">
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[#a1a1a1] text-[13px] text-left text-nowrap">
        <p className="block leading-[16px] whitespace-pre">
          Will you provide assets for your website?*
        </p>
      </div>
      <Frame25 />
      <div
        className="font-['Geist:Light',_sans-serif] leading-[0] min-w-full not-italic relative shrink-0 text-[12px] text-[rgba(255,255,255,0.5)] text-left"
        style={{ width: "min-content" }}
      >
        <p className="block leading-[12px]">
          This would include: all copy (bios, headlines, products, about pages,
          etc.), images and all kind of assets, brand guidelines and so on.
        </p>
      </div>
    </div>
  );
}

function Input10() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-start justify-start p-0 relative shrink-0 w-full"
      data-name="_Input"
    >
      <div className="basis-0 font-['Geist:Regular',_sans-serif] font-normal grow leading-[0] min-h-px min-w-px relative shrink-0 text-[#888888] text-[14px] text-left">
        <p className="block leading-[20px]">https://urlwebsite.com</p>
      </div>
    </div>
  );
}

function Input11() {
  return (
    <div
      className="basis-0 grow h-10 min-h-px min-w-px relative shrink-0"
      data-name="Input"
    >
      <div className="flex flex-col justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 h-10 items-start justify-center px-3 py-0 relative w-full">
          <Input10 />
        </div>
      </div>
    </div>
  );
}

function Input12() {
  return (
    <div
      className="bg-neutral-950 h-10 relative rounded-md shrink-0 w-full"
      data-name="Input"
    >
      <div className="box-border content-stretch flex flex-row h-10 items-center justify-start overflow-clip p-0 relative w-full">
        <Input11 />
      </div>
      <div className="absolute border border-[#2e2e2e] border-solid inset-0 pointer-events-none rounded-md" />
    </div>
  );
}

function Input13() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Input"
    >
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[#a1a1a1] text-[13px] text-left text-nowrap">
        <p className="block leading-[16px] whitespace-pre">
          Project Website (if any)
        </p>
      </div>
      <Input12 />
    </div>
  );
}

function ArrowUp14() {
  return (
    <div className="relative shrink-0 size-4" data-name="arrow-up">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="arrow-up">
          <path
            d={svgPaths.p2b9ec400}
            id="Vector"
            stroke="var(--stroke-0, #0A0A0A)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="1.33333"
          />
        </g>
      </svg>
    </div>
  );
}

function Button7() {
  return (
    <div
      className="bg-[#ededed] h-10 relative rounded-md shrink-0 w-full"
      data-name="Button"
    >
      <div className="flex flex-row items-center justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-10 items-center justify-center px-3 py-0 relative w-full">
          <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[14px] text-center text-neutral-950 text-nowrap">
            <p className="block leading-[20px] whitespace-pre">Get a quote</p>
          </div>
          <ArrowUp14 />
        </div>
      </div>
    </div>
  );
}

function Frame62() {
  return (
    <div className="box-border content-stretch flex flex-col gap-2 items-start justify-start p-0 relative shrink-0 w-full">
      <Button7 />
      <div className="font-['Geist:Regular',_sans-serif] font-normal leading-[0] relative shrink-0 text-[13px] text-[rgba(255,255,255,0.5)] text-left w-full">
        <p className="block leading-[16px]">
          No spam. Your privacy is important to us.
        </p>
      </div>
    </div>
  );
}

function Frame63() {
  return (
    <div className="bg-neutral-950 relative rounded-lg shrink-0 w-full">
      <div className="absolute border-[0.5px] border-[rgba(209,209,209,0.3)] border-solid inset-0 pointer-events-none rounded-lg" />
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-6 items-center justify-center p-[16px] relative w-full">
          <Frame61 />
          <Input3 />
          <Input7 />
          <Select1 />
          <Textarea />
          <Frame26 />
          <Input13 />
          <Frame62 />
        </div>
      </div>
    </div>
  );
}

function Frame64() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2.5 items-start justify-start px-4 py-0 relative w-full">
          <Frame63 />
        </div>
      </div>
    </div>
  );
}

function Frame22() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-24 items-start justify-start left-0 p-0 top-[855px] w-[393px]">
      <Frame5 />
      <Frame29 />
      <Frame6 />
      <Frame64 />
    </div>
  );
}

function ChevronDownDouble() {
  return (
    <div
      className="absolute size-6 top-[780px] translate-x-[-50%]"
      data-name="chevron-down-double"
      style={{ left: "calc(50% + 0.5px)" }}
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 24 24"
      >
        <g id="chevron-down-double">
          <path
            d={svgPaths.p2c1fa800}
            id="Icon"
            stroke="var(--stroke-0, white)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
          />
        </g>
      </svg>
    </div>
  );
}

function StatusBarTime() {
  return (
    <div
      className="h-[21px] relative rounded-3xl shrink-0 w-[54px]"
      data-name="_StatusBar-time"
    >
      <div className="absolute font-['SF_Pro_Text:Semibold',_sans-serif] h-5 leading-[0] left-[27px] not-italic text-[#ffffff] text-[16px] text-center top-px tracking-[-0.32px] translate-x-[-50%] w-[54px]">
        <p className="adjustLetterSpacing block leading-[21px]">9:41</p>
      </div>
    </div>
  );
}

function LeftSide() {
  return (
    <div
      className="basis-0 grow h-full min-h-px min-w-px opacity-0 relative shrink-0"
      data-name="Left Side"
    >
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-center justify-center pb-[3px] pl-2.5 pr-0 pt-0 relative size-full">
          <StatusBarTime />
        </div>
      </div>
    </div>
  );
}

function TrueDepthCamera() {
  return (
    <div
      className="absolute bg-[#000000] h-[37px] rounded-[100px] top-1/2 translate-x-[-50%] translate-y-[-50%] w-20"
      data-name="TrueDepth camera"
      style={{ left: "calc(50% - 22.5px)" }}
    />
  );
}

function FaceTimeCamera() {
  return (
    <div
      className="absolute bg-[#000000] rounded-[100px] size-[37px] top-1/2 translate-x-[-50%] translate-y-[-50%]"
      data-name="FaceTime camera"
      style={{ left: "calc(50% + 44px)" }}
    />
  );
}

function StatusBarDynamicIsland() {
  return (
    <div
      className="bg-[#000000] h-[37px] relative rounded-[100px] shrink-0 w-[125px]"
      data-name="StatusBar-dynamicIsland"
    >
      <TrueDepthCamera />
      <FaceTimeCamera />
    </div>
  );
}

function DynamicIsland() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-full items-center justify-center opacity-0 p-0 relative shrink-0"
      data-name="Dynamic Island"
    >
      <StatusBarDynamicIsland />
    </div>
  );
}

function SignalWifiBattery() {
  return (
    <div
      className="h-[13px] relative shrink-0 w-[78.401px]"
      data-name="Signal, Wifi, Battery"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 79 13"
      >
        <g id="Signal, Wifi, Battery">
          <g id="Icon / Mobile Signal">
            <path d={svgPaths.p1ec31400} fill="var(--fill-0, white)" />
            <path d={svgPaths.p19f8d480} fill="var(--fill-0, white)" />
            <path d={svgPaths.p13f4aa00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p1bfb7500} fill="var(--fill-0, white)" />
          </g>
          <path d={svgPaths.p74e6d40} fill="var(--fill-0, white)" id="Wifi" />
          <g id="_StatusBar-battery">
            <path
              d={svgPaths.pa870f80}
              id="Outline"
              opacity="0.35"
              stroke="var(--stroke-0, white)"
              strokeWidth="1.05509"
            />
            <path
              d={svgPaths.p9c6aca0}
              fill="var(--fill-0, white)"
              id="Battery End"
              opacity="0.4"
            />
            <path
              d={svgPaths.p2cb42c00}
              fill="var(--fill-0, white)"
              id="Fill"
            />
          </g>
        </g>
      </svg>
    </div>
  );
}

function RightSide() {
  return (
    <div
      className="basis-0 grow h-full min-h-px min-w-px opacity-0 relative shrink-0"
      data-name="Right Side"
    >
      <div className="flex flex-row items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2 items-center justify-center pl-0 pr-[11px] py-0 relative size-full">
          <SignalWifiBattery />
        </div>
      </div>
    </div>
  );
}

function StatusBar() {
  return (
    <div
      className="backdrop-blur-2xl backdrop-filter box-border content-stretch flex flex-row h-[59px] items-end justify-center p-0 pointer-events-auto sticky top-0 translate-x-[-50%] w-[393px]"
      data-name="StatusBar"
    >
      <LeftSide />
      <DynamicIsland />
      <RightSide />
    </div>
  );
}

function Logomark1() {
  return (
    <div
      className="[grid-area:1_/_1] h-[29.684px] ml-0 mt-0 relative w-[24.737px]"
      data-name="Logomark"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 25 30"
      >
        <g id="Logomark" opacity="0.84">
          <path
            clipRule="evenodd"
            d={svgPaths.p272b2500}
            fill="var(--fill-0, white)"
            fillRule="evenodd"
            id="Vector"
            opacity="0.5"
          />
          <path
            clipRule="evenodd"
            d={svgPaths.p1a6dcb80}
            fill="var(--fill-0, white)"
            fillRule="evenodd"
            id="Vector_2"
            opacity="0.7"
          />
          <path
            clipRule="evenodd"
            d={svgPaths.p5344000}
            fill="var(--fill-0, white)"
            fillRule="evenodd"
            id="Vector_3"
          />
        </g>
      </svg>
    </div>
  );
}

function Logotext1() {
  return (
    <div
      className="[grid-area:1_/_1] h-[29.684px] ml-[30.921px] mt-0 relative w-[63.079px]"
      data-name="Logotext"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 64 30"
      >
        <g id="Logotext" opacity="0.84">
          <g id="Vector">
            <path d={svgPaths.p3d58b100} fill="var(--fill-0, white)" />
            <path
              clipRule="evenodd"
              d={svgPaths.p18325570}
              fill="var(--fill-0, white)"
              fillRule="evenodd"
            />
            <path
              clipRule="evenodd"
              d={svgPaths.p2c470900}
              fill="var(--fill-0, white)"
              fillRule="evenodd"
            />
            <path d={svgPaths.p4c4ba80} fill="var(--fill-0, white)" />
            <path
              clipRule="evenodd"
              d={svgPaths.p21aa5300}
              fill="var(--fill-0, white)"
              fillRule="evenodd"
            />
            <path d={svgPaths.p2e87ff00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p14573b00} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Group2() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Logomark1 />
      <Logotext1 />
    </div>
  );
}

function Content() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-8 items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Content"
    >
      <Group2 />
    </div>
  );
}

function ButtonsButton() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-1.5 items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="Buttons/Button"
    >
      <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#94979c] text-[14px] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Home</p>
      </div>
    </div>
  );
}

function FooterLink() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative shrink-0"
      data-name="_Footer link"
    >
      <ButtonsButton />
    </div>
  );
}

function ButtonsButton1() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-1.5 items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="Buttons/Button"
    >
      <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#94979c] text-[14px] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Services</p>
      </div>
    </div>
  );
}

function FooterLink1() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative shrink-0"
      data-name="_Footer link"
    >
      <ButtonsButton1 />
    </div>
  );
}

function ButtonsButton2() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-1.5 items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="Buttons/Button"
    >
      <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#94979c] text-[14px] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Projects</p>
      </div>
    </div>
  );
}

function FooterLink2() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative shrink-0"
      data-name="_Footer link"
    >
      <ButtonsButton2 />
    </div>
  );
}

function FooterLinks() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-3 items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Footer links"
    >
      <FooterLink />
      <FooterLink1 />
      <FooterLink2 />
    </div>
  );
}

function FooterLinksColumn() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-col gap-4 grow items-start justify-start min-h-px min-w-24 p-0 relative shrink-0"
      data-name="_Footer links column"
    >
      <FooterLinks />
    </div>
  );
}

function ButtonsButton3() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-1.5 items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="Buttons/Button"
    >
      <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#94979c] text-[14px] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Instagram</p>
      </div>
    </div>
  );
}

function FooterLink3() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative shrink-0"
      data-name="_Footer link"
    >
      <ButtonsButton3 />
    </div>
  );
}

function ButtonsButton4() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-1.5 items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="Buttons/Button"
    >
      <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#94979c] text-[14px] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Behance</p>
      </div>
    </div>
  );
}

function FooterLink4() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative shrink-0"
      data-name="_Footer link"
    >
      <ButtonsButton4 />
    </div>
  );
}

function ButtonsButton5() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-1.5 items-center justify-center overflow-clip p-0 relative shrink-0"
      data-name="Buttons/Button"
    >
      <div className="font-['Geist:Medium',_sans-serif] font-medium leading-[0] relative shrink-0 text-[#94979c] text-[14px] text-left text-nowrap">
        <p className="block leading-[20px] whitespace-pre">Linkedin</p>
      </div>
    </div>
  );
}

function FooterLink5() {
  return (
    <div
      className="box-border content-stretch flex flex-row gap-2 items-center justify-start p-0 relative shrink-0"
      data-name="_Footer link"
    >
      <ButtonsButton5 />
    </div>
  );
}

function FooterLinks1() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-3 items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Footer links"
    >
      <FooterLink3 />
      <FooterLink4 />
      <FooterLink5 />
    </div>
  );
}

function FooterLinksColumn1() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-col gap-4 grow items-start justify-start min-h-px min-w-24 p-0 relative shrink-0"
      data-name="_Footer links column"
    >
      <FooterLinks1 />
    </div>
  );
}

function Content1() {
  return (
    <div
      className="[flex-flow:wrap] box-border content-start flex gap-8 items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Content"
    >
      <FooterLinksColumn />
      <FooterLinksColumn1 />
    </div>
  );
}

function Container() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-8 items-start justify-start px-4 py-0 relative w-full">
          <Content />
          <Content1 />
        </div>
      </div>
    </div>
  );
}

function FooterLinks2() {
  return (
    <div
      className="box-border content-stretch flex flex-row font-['Geist:Regular',_sans-serif] font-normal gap-4 items-start justify-start leading-[0] p-0 relative shrink-0 text-[#94979c] text-[14px] text-left text-nowrap"
      data-name="Footer links"
    >
      <div className="relative shrink-0">
        <p className="block leading-[20px] text-nowrap whitespace-pre">Terms</p>
      </div>
      <div className="relative shrink-0">
        <p className="block leading-[20px] text-nowrap whitespace-pre">
          Privacy
        </p>
      </div>
      <div className="relative shrink-0">
        <p className="block leading-[20px] text-nowrap whitespace-pre">
          Cookies
        </p>
      </div>
    </div>
  );
}

function Content2() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-4 items-start justify-start pb-0 pt-8 px-0 relative shrink-0 w-full"
      data-name="Content"
    >
      <div className="absolute border-[#22262f] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <FooterLinks2 />
      <div
        className="font-['Geist:Light',_sans-serif] leading-[0] min-w-full not-italic relative shrink-0 text-[#94979c] text-[14px] text-left"
        style={{ width: "min-content" }}
      >
        <p className="block leading-[20px]">
          © 2077 Untitled UI. All rights reserved.
        </p>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col gap-8 items-start justify-start px-4 py-0 relative w-full">
          <Content2 />
        </div>
      </div>
    </div>
  );
}

function Footer() {
  return (
    <div
      className="absolute bg-neutral-950 bottom-[0.316px] box-border content-stretch flex flex-col gap-12 items-center justify-start left-1/2 overflow-clip px-0 py-12 translate-x-[-50%] w-[393px]"
      data-name="Footer"
    >
      <Container />
      <Container1 />
    </div>
  );
}

export default function Facu() {
  return (
    <div
      className="bg-[#000000] overflow-clip relative rounded-3xl size-full"
      data-name="Facu"
    >
      <div className="absolute flex h-[795px] items-center justify-center left-[-101px] mix-blend-darken top-12 w-[596.844px]">
        <div className="flex-none rotate-[90deg]">
          <div
            className="bg-center bg-cover bg-no-repeat h-[596.854px] w-[795px]"
            data-name="d8e6eb6b345ada088e2448947c483ab4 3"
            style={{
              backgroundImage: `url('${imgD8E6Eb6B345Ada088E2448947C483Ab47}')`,
            }}
          />
        </div>
      </div>
      <Frame1 />
      <Frame4 />
      <Frame22 />
      <ChevronDownDouble />
      <div className="absolute bottom-0 left-1/2 pointer-events-none top-0">
        <StatusBar />
      </div>
      <Footer />
    </div>
  );
}